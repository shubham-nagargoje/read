#include<stdio.h>
#include<iostream>
#include<cstdlib>

#include<chrono>
#include<omp.h>

using namespace std::chrono;

using namespace std;
#define MAX 100000



int main()
{
int a[MAX],b[MAX],c[MAX],i;
printf("\n First Vector:\t");

for (int i = 0; i < MAX; ++i)
{
	a[i] = 1;
	b[i] = 1;
}

//int t=omp_get_max_threads();
//printf("%d\n",t);

//printf("\n Parallel-Vector Addition:(a,b,c)\t");


auto start = high_resolution_clock::now();
//auto durs = duration_cast<microseconds>(start); 
//cout << durs.count() << endl;

#pragma omp parallel for
for(i=0;i<MAX;i++)
	{
		c[i]=a[i]+b[i];
	}


auto end = high_resolution_clock::now();
auto duration = duration_cast<nanoseconds>(end-start);

cout << duration.count() << endl;

//int n=omp_get_num_threads();
//printf("%d\n",n);

/*for(i=0;i<MAX;i++)
	{
		printf("\n%d\t%d\t%d",a[i],b[i],c[i]);
	}
*/
}